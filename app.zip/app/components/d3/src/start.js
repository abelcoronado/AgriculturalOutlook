d3 = (function(){
  var d3 = {version: "3.1.5"}; // semver
